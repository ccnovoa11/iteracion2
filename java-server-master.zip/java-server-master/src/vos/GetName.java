package vos;

public interface GetName {
	
	public String getClassName();

}
