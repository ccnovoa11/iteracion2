# java-server
Basic REST/JDBC server based on RedHat Wildfly
